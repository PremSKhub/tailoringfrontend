import { Routes, Route } from "react-router-dom";

import Home from './components/Home/Home'
import ExistingCustomer from './components/ExistingCustomer/ExistingCustomer'
import NewCustomer from './components/NewCustomer/NewCustomer'
import './App.css'
import MeasurementEntry from './components/MeasurementEntry/MeasurementEntry'
import MeasurementDetails from './components/MeasurementDetails/MeasurementDetails'
import OrderDetails from './components/OrderDetails/OrderDetails'
import Appointment from './components/Appointment/Appointment'
import PlaceOrder from './components/PlaceOrder/PlaceOrder'

function App() {
  

  return (
    <>
      {/* <Home></Home> */}
      {/* <ExistingCustomer></ExistingCustomer> */}
      {/* <NewCustomer></NewCustomer> */}
      {/* <MeasurementEntry></MeasurementEntry> */}
      {/* <MeasurementDetails></MeasurementDetails> */}
      {/* <OrderDetails></OrderDetails> */}
      {/* <Appointment></Appointment> */}
      {/* <PlaceOrder></PlaceOrder> */}
      <Routes>
        <Route path="/" element={<Home></Home>}/> 
        <Route path="/home" element={<Home></Home>}/> 
        <Route path="/existing-customer" element={<ExistingCustomer></ExistingCustomer>}/>
        <Route path="/existing-customer/:id/measurement-details" element={<MeasurementDetails></MeasurementDetails>}/>
        <Route path="/new-customer" element={<NewCustomer />}/> 
        
      </Routes>
    </>
  )
}

export default App
