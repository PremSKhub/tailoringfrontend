import React from 'react'

import './NewCustomer.css'
import Page1Logo from '../../assets/page1logo.png'
const NewCustomer = () => {
  return (
    <section className='new-customer-container'>
      <div className="header">
        <img src={Page1Logo} alt="Logo" />
      </div>
      <div className="container">
        <h1>New Customer</h1>
        <form>
          <div className="name-fields">
            <div className="form-group">
              <input type="text" id="firstName" name="firstName" placeholder=" " required />
              <label htmlFor="firstName">First Name</label>
            </div>
            <div className="form-group">
              <input type="text" id="lastName" name="lastName" placeholder=" " required />
              <label htmlFor="lastName">Last Name</label>
            </div>
          </div>
          <div className="phone-email-fields">
            <div className="form-group">
              <input type="tel" id="phone" name="phone" placeholder=" " required />
              <label htmlFor="phone">Phone Number</label>
            </div>
            <div className="form-group">
              <input type="email" id="email" name="email" placeholder=" " required />
              <label htmlFor="email">Email</label>
            </div>
          </div>
          <div className="gender-fields">
            <label htmlFor="gender">Gender:</label>
            <div className="form-group">
              <input type="radio" id="male" name="gender" defaultValue="male" required />
              <label htmlFor="male">Male</label>
            </div>
            <div className="form-group">
              <input type="radio" id="female" name="gender" defaultValue="female" required />
              <label htmlFor="female">Female</label>
            </div>
          </div>
          <div className="form-group">
            <input type="text" id="addressLine1" name="addressLine1" placeholder=" " required />
            <label htmlFor="addressLine1">Address Line 1</label>
          </div>
          <div className="form-group">
            <input type="text" id="addressLine2" name="addressLine2" placeholder=" " />
            <label htmlFor="addressLine2">Address Line 2</label>
          </div>
          <div className="form-group">
            <input type="text" id="city" name="city" placeholder=" " required />
            <label htmlFor="city">City</label>
          </div>
          <div className="form-group">
            <input type="text" id="state" name="state" placeholder=" " required />
            <label htmlFor="state">State</label>
          </div>
          <div className="form-group">
            <input type="text" id="postalCode" name="postalCode" placeholder=" " required />
            <label htmlFor="postalCode">Postal Code</label>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>

    </section>
  )
}

export default NewCustomer