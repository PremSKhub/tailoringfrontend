import React from 'react'

import './OrderDetails.css'
import Page1Logo from '../../assets/page1logo.png'
const OrderDetails = () => {
  return (
    <section className='order-details-container'>

      <div className="header">
        <img src={Page1Logo} alt="Logo" />
      </div>
      <div className="container mt-5">
        <h1 className="heading">Existing Customers &gt; Order Details</h1>
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th scope="col">S.No</th>
              <th scope="col">Measurement ID</th>
              <th scope="col">Type of Dress</th>
              <th scope="col">Fabric Details</th>
              <th scope="col">Order ID</th>
              <th scope="col">Due Date</th>
              <th scope="col">Delivery Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>101</td>
              <td>Shirt</td>
              <td>Cotton, Blue</td>
              <td>ORD001</td>
              <td>2024-08-10</td>
              <td>2024-08-12</td>
            </tr>
            <tr>
              <td>2</td>
              <td>102</td>
              <td>Pants</td>
              <td>Denim, Black</td>
              <td>ORD002</td>
              <td>2024-08-15</td>
              <td>2024-08-17</td>
            </tr>
            <tr>
              <td>3</td>
              <td>103</td>
              <td>Jacket</td>
              <td>Leather, Brown</td>
              <td>ORD003</td>
              <td>2024-08-20</td>
              <td>2024-08-22</td>
            </tr>
            <tr>
              <td>4</td>
              <td>104</td>
              <td>Skirt</td>
              <td>Silk, Red</td>
              <td>ORD004</td>
              <td>2024-08-25</td>
              <td>2024-08-27</td>
            </tr>
            <tr>
              <td>5</td>
              <td>105</td>
              <td>Dress</td>
              <td>Linen, White</td>
              <td>ORD005</td>
              <td>2024-08-30</td>
              <td>2024-09-01</td>
            </tr>
          </tbody>
        </table>
      </div>


    </section>
  )
}

export default OrderDetails