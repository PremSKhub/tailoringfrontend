import React from 'react'

import './MeasurementEntry.css'
import Page1Logo from '../../assets/page1logo.png'
const MeasurementEntry = () => {
  return (
    <section className='measurement-entry-container'>
      <div className="header">
        <img src={Page1Logo} alt="Logo" />
      </div>
      <div className="container">
        <h1>Measurement Form</h1>
        <form>
          <div className="form-group">
            <label htmlFor="hip">Hip</label>
            <input type="number" id="hip" name="hip" placeholder="Value" required />
            <select name="hipUnit" id="hipUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="neck">Neck</label>
            <input type="number" id="neck" name="neck" placeholder="Value" required />
            <select name="neckUnit" id="neckUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="chest">Chest</label>
            <input type="number" id="chest" name="chest" placeholder="Value" required />
            <select name="chestUnit" id="chestUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="waist">Waist</label>
            <input type="number" id="waist" name="waist" placeholder="Value" required />
            <select name="waistUnit" id="waistUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="shoulder">Shoulder</label>
            <input type="number" id="shoulder" name="shoulder" placeholder="Value" required />
            <select name="shoulderUnit" id="shoulderUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="sleeve">Sleeve</label>
            <input type="number" id="sleeve" name="sleeve" placeholder="Value" required />
            <select name="sleeveUnit" id="sleeveUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="arm">Arm</label>
            <input type="number" id="arm" name="arm" placeholder="Value" required />
            <select name="armUnit" id="armUnit">
              <option value="cm">cm</option>
              <option value="m">m</option>
            </select>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>

    </section>
  )
}

export default MeasurementEntry