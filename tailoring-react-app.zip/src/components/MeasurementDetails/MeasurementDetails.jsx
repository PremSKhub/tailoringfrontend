import React from 'react'
import { useParams } from 'react-router-dom'

import './MeasurementDetails.css'
import Page1Logo from '../../assets/page1logo.png'
const MeasurementDetails = () => {
  const params = useParams();
  console.log("Customer ID ====>", params.id)
  return (
    <section className='measurement-details-container'>
      <div className="header">
        <img src={Page1Logo} alt="Logo" />
      </div>
      <div className="container mt-5">
        <h1 className="heading">Existing Customer / Measurement Details</h1>
        <div className="table-container mx-auto">
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                <th scope="col">S.No</th>
                <th scope="col">Measurement</th>
                <th scope="col">Value</th>
                <th scope="col">Unit</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Hip</td>
                <td>180</td>
                <td>cm</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>2</td>
                <td>Neck</td>
                <td>75</td>
                <td>kg</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>3</td>
                <td>Chest</td>
                <td>32</td>
                <td>inches</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>4</td>
                <td>Waist</td>
                <td>42</td>
                <td>inches</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>5</td>
                <td>Shoulder</td>
                <td>40</td>
                <td>inches</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>6</td>
                <td>Sleeve</td>
                <td>18</td>
                <td>inches</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
              <tr>
                <td>7</td>
                <td>Arm</td>
                <td>32</td>
                <td>inches</td>
                <td>
                  <div className="action-icons">
                    <a href="#"> <img src="../Images/edit.svg" />
                      <i className="bi bi-pencil" />
                    </a>
                    <a href="#"> <img src="../Images/trash.svg" />
                      <i className="bi bi-trash" />
                    </a>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </section>
  )
}

export default MeasurementDetails