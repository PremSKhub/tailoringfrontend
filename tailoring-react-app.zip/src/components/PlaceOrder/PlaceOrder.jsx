import React from 'react'

import './PlaceOrder.css'
import Page1Logo from '../../assets/page1logo.png'
const PlaceOrder = () => {
  return (
    <section className='place-order-container'>
      <div>
        <div classname="header">
          <img src={Page1Logo} alt="Logo" />
        </div>
        <div classname="container">
          <h1 classname="heading">Place An Order</h1>
          <div classname="form-group">
            <label htmlfor="customer-name">Customer's Measurements</label>
            <select classname="form-select" id="customer-name">
              <option selected>Select Customer</option>
              <option value="Customer 1">Customer 1</option>
              <option value="Customer 2">Customer 2</option>
              <option value="Customer 3">Customer 3</option>
              <option value="Customer 4">Customer 4</option>
              <option value="Customer 5">Customer 5</option>
            </select>
            <label htmlfor="fabric-type">Fabric's Details</label>
            <select classname="form-select" id="fabric-type">
              <option selected>Select Fabric</option>
              <option value="Cotton">Cotton</option>
              <option value="Silk">Silk</option>
              <option value="Wool">Wool</option>
              <option value="Linen">Linen</option>
              <option value="Polyester">Polyester</option>
            </select>
          </div>
          <div classname="form-row">
            <label htmlfor="instructions" classname="section-heading">Special Instructions</label>
            <textarea classname="form-control" id="instructions" rows="{3}" placeholder="Enter any special instructions" defaultvalue="{&quot;&quot;}" defaultValue={"    </div>\n    <div className=\"d-grid\">\n      <button type=\"submit\" className=\"btn btn-primary btn-submit\">Submit</button>\n    </div>\n  </div>\n</div>\n"} /></div></div></div>


    </section>
  )
}

export default PlaceOrder